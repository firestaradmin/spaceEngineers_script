﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Malware.MDKServices.Legacy
{
    // ReSharper disable once InconsistentNaming because this is an exception to the rule.
    class ProjectUpgrader_1_2
    {

    }
}
