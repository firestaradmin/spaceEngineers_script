using System;

namespace Malware.MDKUtilities
{
    /// <summary>
    ///     Factory class for constructing various mockups and utilities
    /// </summary>
    [Obsolete("Use MDKFactory directly.")]
    public class MDK: MDKFactory
    { }
}
