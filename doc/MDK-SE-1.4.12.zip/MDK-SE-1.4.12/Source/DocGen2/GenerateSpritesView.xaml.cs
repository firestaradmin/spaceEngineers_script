﻿using System.Windows.Controls;

namespace Mal.DocGen2
{
    /// <summary>
    ///     Interaction logic for GenerateTerminalDocumentView.xaml
    /// </summary>
    public partial class GenerateSpritesView: UserControl
    {
        public GenerateSpritesView()
        {
            InitializeComponent();
        }
    }
}