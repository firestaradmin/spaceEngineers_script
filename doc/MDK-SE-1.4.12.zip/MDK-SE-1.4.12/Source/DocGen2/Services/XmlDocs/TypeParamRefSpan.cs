﻿namespace Mal.DocGen2.Services.XmlDocs
{
    class TypeParamRefSpan : Span
    {
        public TypeParamRefSpan(string textValue) : base(textValue)
        { }
    }
}