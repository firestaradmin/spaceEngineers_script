﻿namespace Mal.DocGen2.Services.XmlDocs
{
    public enum ParagraphType
    {
        Default,
        Example,
        Param,
        Code,
        Remarks,
        Summary,
        Value,
        Member,
        Returns
    }
}