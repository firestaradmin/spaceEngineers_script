﻿namespace Mal.DocGen2.Services.XmlDocs
{
    class ParamRefSpan : Span
    {
        public ParamRefSpan(string textValue) : base(textValue)
        { }
    }
}