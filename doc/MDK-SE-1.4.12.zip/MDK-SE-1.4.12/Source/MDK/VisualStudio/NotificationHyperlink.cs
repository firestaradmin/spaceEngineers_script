﻿namespace MDK.VisualStudio
{
    /// <summary>
    /// A notification bar hyperlink
    /// </summary>
    public class NotificationHyperlink : NotificationAction
    {
        /// <summary>
        /// Creates a new <see cref="NotificationHyperlink"/>
        /// </summary>
        public NotificationHyperlink() : base(false) { }
    }
}