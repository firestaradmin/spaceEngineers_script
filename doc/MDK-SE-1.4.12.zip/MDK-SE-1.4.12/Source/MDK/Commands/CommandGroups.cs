﻿using System;

namespace MDK.Commands
{
    static class CommandGroups
    {
        public static readonly Guid MDKGroup = new Guid("2c5d90b4-d8c7-476a-8877-00f5c0803bdb");
    }
}
