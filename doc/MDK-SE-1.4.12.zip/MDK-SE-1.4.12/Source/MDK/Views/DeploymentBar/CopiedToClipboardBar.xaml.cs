﻿using MDK.VisualStudio;

namespace MDK.Views.DeploymentBar
{
    /// <summary>
    /// Interaction logic for DeploymentBar.xaml
    /// </summary>
    public partial class CopiedToClipboardBar : NotificationBar
    {
        /// <summary>
        /// Creates a new instance of <see cref="DeploymentBar"/>
        /// </summary>
        public CopiedToClipboardBar() { InitializeComponent(); }
    }
}
