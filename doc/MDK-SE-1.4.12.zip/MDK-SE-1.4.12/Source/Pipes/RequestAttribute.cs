﻿using System;

namespace Pipes
{
    [AttributeUsage(AttributeTargets.Method)]
    public class RequestAttribute: Attribute
    { }
}