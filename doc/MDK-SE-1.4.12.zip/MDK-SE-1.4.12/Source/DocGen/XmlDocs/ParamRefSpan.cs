﻿namespace DocGen.XmlDocs
{
    class ParamRefSpan : Span
    {
        public ParamRefSpan(string textValue) : base(textValue)
        { }
    }
}