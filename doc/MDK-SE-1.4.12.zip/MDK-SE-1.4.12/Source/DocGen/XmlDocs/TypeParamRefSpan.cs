﻿namespace DocGen.XmlDocs
{
    class TypeParamRefSpan : Span
    {
        public TypeParamRefSpan(string textValue) : base(textValue)
        { }
    }
}