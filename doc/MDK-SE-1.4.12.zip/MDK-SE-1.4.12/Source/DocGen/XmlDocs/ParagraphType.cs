﻿namespace DocGen.XmlDocs
{
    public enum ParagraphType
    {
        Default,
        Example,
        Param,
        Code,
        Remarks,
        Summary,
        Value,
        Member,
        Returns
    }
}