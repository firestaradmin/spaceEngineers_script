using System;

namespace Malware.MDKServices 
{
	partial class MDKProjectProperties 
    {
	    /// <summary>
		/// The current package version this utility assembly targets
		/// </summary>
		public static readonly Version TargetPackageVersion = new Version("1.4.9");
	}
}
