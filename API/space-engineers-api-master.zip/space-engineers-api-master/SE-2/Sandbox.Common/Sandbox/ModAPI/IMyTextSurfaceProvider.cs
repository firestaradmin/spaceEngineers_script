using Sandbox.ModAPI.Ingame;

namespace Sandbox.ModAPI
{
	/// <summary>
	/// Describes block, that has at least 1 text surface (mods interface)
	/// </summary>
	public interface IMyTextSurfaceProvider : Sandbox.ModAPI.Ingame.IMyTextSurfaceProvider
	{
	}
}
