using VRageMath;

namespace Sandbox.ModAPI
{
	public delegate void MissileMoveDelegate(IMyMissile missile, ref Vector3 Velocity);
}
