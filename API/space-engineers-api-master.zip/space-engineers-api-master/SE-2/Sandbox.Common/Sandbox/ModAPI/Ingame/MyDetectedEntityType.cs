namespace Sandbox.ModAPI.Ingame
{
	public enum MyDetectedEntityType
	{
		None,
		Unknown,
		SmallGrid,
		LargeGrid,
		CharacterHuman,
		CharacterOther,
		FloatingObject,
		Asteroid,
		Planet,
		Meteor,
		Missile
	}
}
