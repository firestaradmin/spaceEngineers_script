namespace Sandbox.ModAPI.Ingame
{
	public enum MyJumpDriveStatus
	{
		Charging,
		Ready,
		Jumping
	}
}
