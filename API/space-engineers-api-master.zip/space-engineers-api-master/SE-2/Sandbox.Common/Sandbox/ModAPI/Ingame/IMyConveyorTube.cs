using VRage.Game.ModAPI.Ingame;

namespace Sandbox.ModAPI.Ingame
{
	/// <summary>
	/// Describes conveyor tube block (PB scripting interface)
	/// </summary>
	public interface IMyConveyorTube : IMyCubeBlock, IMyEntity
	{
	}
}
