using VRage.Game.ModAPI.Ingame;

namespace Sandbox.ModAPI.Ingame
{
<<<<<<< HEAD
	/// <summary>
	/// Describes target dummy block (PB scripting interface)
	/// </summary>
=======
>>>>>>> d46cf8619665219cc163a7b28984ced59ed9470d
	public interface IMyTargetDummyBlock : IMyFunctionalBlock, IMyTerminalBlock, IMyCubeBlock, IMyEntity
	{
	}
}
