namespace Sandbox.ModAPI.Ingame
{
	public enum FlightMode
	{
		Patrol,
		Circle,
		OneWay
	}
}
