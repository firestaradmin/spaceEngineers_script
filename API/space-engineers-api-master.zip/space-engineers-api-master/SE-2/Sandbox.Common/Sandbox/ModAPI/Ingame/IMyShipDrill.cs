using VRage.Game.ModAPI.Ingame;

namespace Sandbox.ModAPI.Ingame
{
	/// <summary>
	/// Describes ship drill block (PB scripting interface)
	/// </summary>
	public interface IMyShipDrill : IMyShipToolBase, IMyFunctionalBlock, IMyTerminalBlock, IMyCubeBlock, IMyEntity
	{
<<<<<<< HEAD
=======
		bool UseConveyorSystem { get; set; }
>>>>>>> d46cf8619665219cc163a7b28984ced59ed9470d
	}
}
