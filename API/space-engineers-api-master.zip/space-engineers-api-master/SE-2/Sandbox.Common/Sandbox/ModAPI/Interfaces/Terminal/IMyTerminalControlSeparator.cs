namespace Sandbox.ModAPI.Interfaces.Terminal
{
	/// <summary>
	/// This is a simple line separator used to separate controls in a visible manner.
	/// </summary>
	public interface IMyTerminalControlSeparator : IMyTerminalControl
	{
	}
}
