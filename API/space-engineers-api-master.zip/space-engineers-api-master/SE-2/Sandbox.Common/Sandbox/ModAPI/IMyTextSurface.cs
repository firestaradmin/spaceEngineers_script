using Sandbox.ModAPI.Ingame;

namespace Sandbox.ModAPI
{
	/// <summary>
	/// Describes one of block LCDs where you can write text or draw things (mods interface)
	/// </summary>
	public interface IMyTextSurface : Sandbox.ModAPI.Ingame.IMyTextSurface
	{
	}
}
