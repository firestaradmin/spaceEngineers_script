# space engineers ingame script API
# 太空工程师 API · 内置 · 程序块
***
太空工程师目前使用的库为 .net.4.6.1

编译语言为 C#

如果你想在太空工程师中编写脚本或者设计大型MOD，本API可以一定程度的帮助到你。

制作mod的同学，请直接翻阅目录

转载请注明出处，谢谢。
