public enum MyMatchState
{
	PreMatch,
	Match,
	PostMatch,
	Finished
}
