using System.Net;

namespace Sandbox.Engine.Multiplayer
{
	public static class MyDedicatedServerOverrides
	{
		public static int? MaxPlayers;

		public static IPAddress IpAddress;

		public static int? Port;
	}
}
