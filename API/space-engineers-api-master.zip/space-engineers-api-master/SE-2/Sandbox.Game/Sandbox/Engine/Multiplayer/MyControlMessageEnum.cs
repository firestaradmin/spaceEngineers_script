namespace Sandbox.Engine.Multiplayer
{
	public enum MyControlMessageEnum : byte
	{
		Kick,
		Disconnected,
		Ban,
		SendPasswordHash
	}
}
