namespace Sandbox.Engine.Analytics
{
	public enum MyWorldEntryEnum
	{
		Quickstart,
		Custom,
		Scenario,
		Tutorial,
		Load,
		Join
	}
}
