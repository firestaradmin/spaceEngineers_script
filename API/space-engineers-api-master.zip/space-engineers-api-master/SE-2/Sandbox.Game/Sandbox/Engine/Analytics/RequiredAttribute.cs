using System;

namespace Sandbox.Engine.Analytics
{
<<<<<<< HEAD
	/// <summary>
	/// Marks a MyAnalyticsEvent property as required (not null)
	/// </summary>
=======
>>>>>>> d46cf8619665219cc163a7b28984ced59ed9470d
	[AttributeUsage(AttributeTargets.Property, Inherited = false)]
	internal class RequiredAttribute : Attribute
	{
	}
}
