using System;

namespace Sandbox.Engine.Analytics
{
<<<<<<< HEAD
	/// <summary>
	/// Marks a class as supported type of MyAnalyticsEvent property
	/// </summary>
=======
>>>>>>> d46cf8619665219cc163a7b28984ced59ed9470d
	[AttributeUsage(AttributeTargets.Class, Inherited = false)]
	internal class SupportedTypeAttribute : Attribute
	{
	}
}
