using System.Collections.Generic;

namespace Sandbox.Definitions
{
	public struct VoxelMapChange
	{
		public Dictionary<byte, byte> Changes;
	}
}
