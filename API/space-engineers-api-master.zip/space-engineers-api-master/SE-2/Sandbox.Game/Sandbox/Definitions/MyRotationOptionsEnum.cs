namespace Sandbox.Definitions
{
	public enum MyRotationOptionsEnum
	{
		None,
		Vertical,
		Horizontal,
		Both
	}
}
