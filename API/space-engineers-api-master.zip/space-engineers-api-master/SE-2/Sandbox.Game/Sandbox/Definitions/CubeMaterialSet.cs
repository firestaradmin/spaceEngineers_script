namespace Sandbox.Definitions
{
	public class CubeMaterialSet
	{
		public string[][,] Models;
	}
}
