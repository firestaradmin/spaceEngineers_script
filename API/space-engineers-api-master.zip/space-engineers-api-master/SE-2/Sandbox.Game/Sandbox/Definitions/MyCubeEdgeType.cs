namespace Sandbox.Definitions
{
	public enum MyCubeEdgeType : byte
	{
		Vertical,
		Vertical_Diagonal,
		Horizontal,
		Horizontal_Diagonal,
		Hidden
	}
}
